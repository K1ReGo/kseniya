﻿namespace EngineeringCalculator
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.mainSplitContainer = new System.Windows.Forms.SplitContainer();
            this.sidebarPanel = new System.Windows.Forms.Panel();
            this.functionGroup = new System.Windows.Forms.GroupBox();
            this.lblExpression = new System.Windows.Forms.Label();
            this.txtExpression = new System.Windows.Forms.TextBox();
            this.btnAddFunction = new System.Windows.Forms.Button();
            this.listGroup = new System.Windows.Forms.GroupBox();
            this.dgvFunctions = new System.Windows.Forms.DataGridView();
            this.colFunction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonContainer = new System.Windows.Forms.Panel();
            this.btnRemoveFunction = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.scaleGroup = new System.Windows.Forms.GroupBox();
            this.scaleGrid = new System.Windows.Forms.TableLayoutPanel();
            this.lblXMin = new System.Windows.Forms.Label();
            this.numXMin = new System.Windows.Forms.NumericUpDown();
            this.lblXMax = new System.Windows.Forms.Label();
            this.numXMax = new System.Windows.Forms.NumericUpDown();
            this.lblYMin = new System.Windows.Forms.Label();
            this.numYMin = new System.Windows.Forms.NumericUpDown();
            this.lblYMax = new System.Windows.Forms.Label();
            this.numYMax = new System.Windows.Forms.NumericUpDown();
            this.calcGroup = new System.Windows.Forms.GroupBox();
            this.calcInputPanel = new System.Windows.Forms.Panel();
            this.txtCalcInput = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblCalcResult = new System.Windows.Forms.Label();
            this.chartPanel = new System.Windows.Forms.Panel();
            this.chartFunctions = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartToolbar = new System.Windows.Forms.Panel();
            this.btnSaveImage = new System.Windows.Forms.Button();
            this.statusBar = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.mainSplitContainer)).BeginInit();
            this.mainSplitContainer.Panel1.SuspendLayout();
            this.mainSplitContainer.Panel2.SuspendLayout();
            this.mainSplitContainer.SuspendLayout();
            this.sidebarPanel.SuspendLayout();
            this.functionGroup.SuspendLayout();
            this.listGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFunctions)).BeginInit();
            this.buttonContainer.SuspendLayout();
            this.scaleGroup.SuspendLayout();
            this.scaleGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numXMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numYMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numYMax)).BeginInit();
            this.calcGroup.SuspendLayout();
            this.calcInputPanel.SuspendLayout();
            this.chartPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartFunctions)).BeginInit();
            this.chartToolbar.SuspendLayout();
            this.statusBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainSplitContainer
            // 
            this.mainSplitContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.mainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainSplitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.mainSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.mainSplitContainer.Margin = new System.Windows.Forms.Padding(5);
            this.mainSplitContainer.Name = "mainSplitContainer";
            // 
            // mainSplitContainer.Panel1
            // 
            this.mainSplitContainer.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(50)))));
            this.mainSplitContainer.Panel1.Controls.Add(this.sidebarPanel);
            this.mainSplitContainer.Panel1.Padding = new System.Windows.Forms.Padding(19);
            this.mainSplitContainer.Panel1MinSize = 440;
            // 
            // mainSplitContainer.Panel2
            // 
            this.mainSplitContainer.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.mainSplitContainer.Panel2.Controls.Add(this.chartPanel);
            this.mainSplitContainer.Size = new System.Drawing.Size(2698, 1459);
            this.mainSplitContainer.SplitterDistance = 460;
            this.mainSplitContainer.SplitterWidth = 2;
            this.mainSplitContainer.TabIndex = 0;
            // 
            // sidebarPanel
            // 
            this.sidebarPanel.AutoScroll = true;
            this.sidebarPanel.BackColor = System.Drawing.Color.Transparent;
            this.sidebarPanel.Controls.Add(this.functionGroup);
            this.sidebarPanel.Controls.Add(this.listGroup);
            this.sidebarPanel.Controls.Add(this.scaleGroup);
            this.sidebarPanel.Controls.Add(this.calcGroup);
            this.sidebarPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sidebarPanel.Location = new System.Drawing.Point(19, 19);
            this.sidebarPanel.Margin = new System.Windows.Forms.Padding(5);
            this.sidebarPanel.Name = "sidebarPanel";
            this.sidebarPanel.Size = new System.Drawing.Size(422, 1421);
            this.sidebarPanel.TabIndex = 0;
            // 
            // functionGroup
            // 
            this.functionGroup.Controls.Add(this.lblExpression);
            this.functionGroup.Controls.Add(this.txtExpression);
            this.functionGroup.Controls.Add(this.btnAddFunction);
            this.functionGroup.Dock = System.Windows.Forms.DockStyle.Top;
            this.functionGroup.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.functionGroup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            this.functionGroup.Location = new System.Drawing.Point(0, 1008);
            this.functionGroup.Margin = new System.Windows.Forms.Padding(5);
            this.functionGroup.Name = "functionGroup";
            this.functionGroup.Padding = new System.Windows.Forms.Padding(26, 32, 26, 26);
            this.functionGroup.Size = new System.Drawing.Size(422, 208);
            this.functionGroup.TabIndex = 1;
            this.functionGroup.TabStop = false;
            this.functionGroup.Text = "➕ Добавить функцию";
            // 
            // lblExpression
            // 
            this.lblExpression.AutoSize = true;
            this.lblExpression.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblExpression.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(180)))));
            this.lblExpression.Location = new System.Drawing.Point(26, 80);
            this.lblExpression.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblExpression.Name = "lblExpression";
            this.lblExpression.Size = new System.Drawing.Size(70, 32);
            this.lblExpression.TabIndex = 0;
            this.lblExpression.Text = "f(x) =";
            // 
            // txtExpression
            // 
            this.txtExpression.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(65)))));
            this.txtExpression.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtExpression.Font = new System.Drawing.Font("Consolas", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtExpression.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.txtExpression.Location = new System.Drawing.Point(128, 70);
            this.txtExpression.Margin = new System.Windows.Forms.Padding(5);
            this.txtExpression.Name = "txtExpression";
            this.txtExpression.Size = new System.Drawing.Size(335, 40);
            this.txtExpression.TabIndex = 1;
            this.txtExpression.Text = "Sin(x)";
            // 
            // btnAddFunction
            // 
            this.btnAddFunction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(140)))), ((int)(((byte)(255)))));
            this.btnAddFunction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddFunction.FlatAppearance.BorderSize = 0;
            this.btnAddFunction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddFunction.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnAddFunction.ForeColor = System.Drawing.Color.White;
            this.btnAddFunction.Location = new System.Drawing.Point(480, 70);
            this.btnAddFunction.Margin = new System.Windows.Forms.Padding(5);
            this.btnAddFunction.Name = "btnAddFunction";
            this.btnAddFunction.Size = new System.Drawing.Size(250, 45);
            this.btnAddFunction.TabIndex = 2;
            this.btnAddFunction.Text = "+ Добавить";
            this.btnAddFunction.UseVisualStyleBackColor = false;
            this.btnAddFunction.Click += new System.EventHandler(this.BtnAddFunction_Click);
            // 
            // listGroup
            // 
            this.listGroup.Controls.Add(this.dgvFunctions);
            this.listGroup.Controls.Add(this.buttonContainer);
            this.listGroup.Dock = System.Windows.Forms.DockStyle.Top;
            this.listGroup.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.listGroup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            this.listGroup.Location = new System.Drawing.Point(0, 432);
            this.listGroup.Margin = new System.Windows.Forms.Padding(5);
            this.listGroup.Name = "listGroup";
            this.listGroup.Padding = new System.Windows.Forms.Padding(26, 32, 26, 26);
            this.listGroup.Size = new System.Drawing.Size(422, 576);
            this.listGroup.TabIndex = 2;
            this.listGroup.TabStop = false;
            this.listGroup.Text = "📊 Список функцмй";
            this.listGroup.Enter += new System.EventHandler(this.listGroup_Enter);
            // 
            // dgvFunctions
            // 
            this.dgvFunctions.AllowUserToAddRows = false;
            this.dgvFunctions.AllowUserToDeleteRows = false;
            this.dgvFunctions.AllowUserToResizeRows = false;
            this.dgvFunctions.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(60)))));
            this.dgvFunctions.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvFunctions.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvFunctions.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(210)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(210)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFunctions.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFunctions.ColumnHeadersHeight = 44;
            this.dgvFunctions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFunction,
            this.colColor});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFunctions.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFunctions.EnableHeadersVisualStyles = false;
            this.dgvFunctions.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(80)))));
            this.dgvFunctions.Location = new System.Drawing.Point(26, 68);
            this.dgvFunctions.Margin = new System.Windows.Forms.Padding(5);
            this.dgvFunctions.Name = "dgvFunctions";
            this.dgvFunctions.ReadOnly = true;
            this.dgvFunctions.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFunctions.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvFunctions.RowHeadersVisible = false;
            this.dgvFunctions.RowHeadersWidth = 51;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.dgvFunctions.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvFunctions.RowTemplate.Height = 36;
            this.dgvFunctions.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvFunctions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFunctions.Size = new System.Drawing.Size(370, 381);
            this.dgvFunctions.TabIndex = 0;
            this.dgvFunctions.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFunctions_CellContentClick);
            this.dgvFunctions.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvFunctions_CellDoubleClick);
            // 
            // colFunction
            // 
            this.colFunction.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFunction.HeaderText = "f(x) =";
            this.colFunction.MinimumWidth = 6;
            this.colFunction.Name = "colFunction";
            this.colFunction.ReadOnly = true;
            // 
            // colColor
            // 
            this.colColor.HeaderText = "Цвет";
            this.colColor.MinimumWidth = 80;
            this.colColor.Name = "colColor";
            this.colColor.ReadOnly = true;
            this.colColor.Width = 0;
            // 
            // buttonContainer
            // 
            this.buttonContainer.Controls.Add(this.btnRemoveFunction);
            this.buttonContainer.Controls.Add(this.btnClear);
            this.buttonContainer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonContainer.Location = new System.Drawing.Point(26, 449);
            this.buttonContainer.Margin = new System.Windows.Forms.Padding(5);
            this.buttonContainer.Name = "buttonContainer";
            this.buttonContainer.Padding = new System.Windows.Forms.Padding(0, 13, 0, 0);
            this.buttonContainer.Size = new System.Drawing.Size(370, 101);
            this.buttonContainer.TabIndex = 1;
            // 
            // btnRemoveFunction
            // 
            this.btnRemoveFunction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnRemoveFunction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveFunction.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnRemoveFunction.FlatAppearance.BorderSize = 0;
            this.btnRemoveFunction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveFunction.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnRemoveFunction.ForeColor = System.Drawing.Color.White;
            this.btnRemoveFunction.Location = new System.Drawing.Point(0, 13);
            this.btnRemoveFunction.Margin = new System.Windows.Forms.Padding(5);
            this.btnRemoveFunction.Name = "btnRemoveFunction";
            this.btnRemoveFunction.Size = new System.Drawing.Size(420, 88);
            this.btnRemoveFunction.TabIndex = 1;
            this.btnRemoveFunction.Text = "🗑 Удалить выбранные";
            this.btnRemoveFunction.UseVisualStyleBackColor = false;
            this.btnRemoveFunction.Click += new System.EventHandler(this.BtnRemoveFunction_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(110)))));
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnClear.FlatAppearance.BorderSize = 0;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(79, 13);
            this.btnClear.Margin = new System.Windows.Forms.Padding(5);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(420, 88);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "🧹 Очистить все";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // scaleGroup
            // 
            this.scaleGroup.Controls.Add(this.scaleGrid);
            this.scaleGroup.Dock = System.Windows.Forms.DockStyle.Top;
            this.scaleGroup.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.scaleGroup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            this.scaleGroup.Location = new System.Drawing.Point(0, 208);
            this.scaleGroup.Margin = new System.Windows.Forms.Padding(5);
            this.scaleGroup.Name = "scaleGroup";
            this.scaleGroup.Padding = new System.Windows.Forms.Padding(26, 32, 26, 26);
            this.scaleGroup.Size = new System.Drawing.Size(422, 224);
            this.scaleGroup.TabIndex = 3;
            this.scaleGroup.TabStop = false;
            this.scaleGroup.Text = "📐 Масштаб осей";
            // 
            // scaleGrid
            // 
            this.scaleGrid.ColumnCount = 4;
            this.scaleGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.scaleGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.scaleGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.scaleGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.scaleGrid.Controls.Add(this.lblXMin, 0, 0);
            this.scaleGrid.Controls.Add(this.numXMin, 1, 0);
            this.scaleGrid.Controls.Add(this.lblXMax, 2, 0);
            this.scaleGrid.Controls.Add(this.numXMax, 3, 0);
            this.scaleGrid.Controls.Add(this.lblYMin, 0, 1);
            this.scaleGrid.Controls.Add(this.numYMin, 1, 1);
            this.scaleGrid.Controls.Add(this.lblYMax, 2, 1);
            this.scaleGrid.Controls.Add(this.numYMax, 3, 1);
            this.scaleGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scaleGrid.Location = new System.Drawing.Point(26, 68);
            this.scaleGrid.Name = "scaleGrid";
            this.scaleGrid.RowCount = 2;
            this.scaleGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.scaleGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.scaleGrid.Size = new System.Drawing.Size(370, 130);
            this.scaleGrid.TabIndex = 0;
            this.scaleGrid.Paint += new System.Windows.Forms.PaintEventHandler(this.scaleGrid_Paint);
            // 
            // lblXMin
            // 
            this.lblXMin.AutoSize = true;
            this.lblXMin.Dock = System.Windows.Forms.DockStyle.None;
            this.lblXMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblXMin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(180)))));
            this.lblXMin.Location = new System.Drawing.Point(0, 0);
            this.lblXMin.Margin = new System.Windows.Forms.Padding(0);
            this.lblXMin.Name = "lblXMin";
            this.lblXMin.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblXMin.Size = new System.Drawing.Size(92, 65);
            this.lblXMin.TabIndex = 0;
            this.lblXMin.Text = "X min:";
            this.lblXMin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numXMin
            // 
            this.numXMin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(65)))));
            this.numXMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numXMin.DecimalPlaces = 2;
            this.numXMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numXMin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.numXMin.Location = new System.Drawing.Point(97, 5);
            this.numXMin.Margin = new System.Windows.Forms.Padding(5);
            this.numXMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numXMin.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numXMin.Name = "numXMin";
            this.numXMin.Size = new System.Drawing.Size(240, 39);
            this.numXMin.TabIndex = 4;
            this.numXMin.Value = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            this.numXMin.ValueChanged += new System.EventHandler(this.NumAxis_ValueChanged);
            // 
            // lblXMax
            // 
            this.lblXMax.AutoSize = true;
            this.lblXMax.Dock = System.Windows.Forms.DockStyle.None;
            this.lblXMax.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblXMax.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(180)))));
            this.lblXMax.Location = new System.Drawing.Point(184, 0);
            this.lblXMax.Margin = new System.Windows.Forms.Padding(0);
            this.lblXMax.Name = "lblXMax";
            this.lblXMax.Padding = new System.Windows.Forms.Padding(13, 6, 0, 0);
            this.lblXMax.Size = new System.Drawing.Size(92, 65);
            this.lblXMax.TabIndex = 1;
            this.lblXMax.Text = "X max:";
            this.lblXMax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblXMax.Click += new System.EventHandler(this.lblXMax_Click);
            // 
            // numXMax
            // 
            this.numXMax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(65)))));
            this.numXMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numXMax.DecimalPlaces = 2;
            this.numXMax.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numXMax.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.numXMax.Location = new System.Drawing.Point(281, 5);
            this.numXMax.Margin = new System.Windows.Forms.Padding(5);
            this.numXMax.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numXMax.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numXMax.Name = "numXMax";
            this.numXMax.Size = new System.Drawing.Size(240, 39);
            this.numXMax.TabIndex = 5;
            this.numXMax.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numXMax.ValueChanged += new System.EventHandler(this.NumAxis_ValueChanged);
            // 
            // lblYMin
            // 
            this.lblYMin.AutoSize = true;
            this.lblYMin.Dock = System.Windows.Forms.DockStyle.None;
            this.lblYMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblYMin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(180)))));
            this.lblYMin.Location = new System.Drawing.Point(0, 65);
            this.lblYMin.Margin = new System.Windows.Forms.Padding(0);
            this.lblYMin.Name = "lblYMin";
            this.lblYMin.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblYMin.Size = new System.Drawing.Size(92, 65);
            this.lblYMin.TabIndex = 2;
            this.lblYMin.Text = "Y min:";
            this.lblYMin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numYMin
            // 
            this.numYMin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(65)))));
            this.numYMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numYMin.DecimalPlaces = 2;
            this.numYMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numYMin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.numYMin.Location = new System.Drawing.Point(97, 70);
            this.numYMin.Margin = new System.Windows.Forms.Padding(5);
            this.numYMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numYMin.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numYMin.Name = "numYMin";
            this.numYMin.Size = new System.Drawing.Size(240, 39);
            this.numYMin.TabIndex = 6;
            this.numYMin.Value = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.numYMin.ValueChanged += new System.EventHandler(this.NumAxis_ValueChanged);
            // 
            // lblYMax
            // 
            this.lblYMax.AutoSize = true;
            this.lblYMax.Dock = System.Windows.Forms.DockStyle.None;
            this.lblYMax.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblYMax.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(180)))));
            this.lblYMax.Location = new System.Drawing.Point(184, 65);
            this.lblYMax.Margin = new System.Windows.Forms.Padding(0);
            this.lblYMax.Name = "lblYMax";
            this.lblYMax.Padding = new System.Windows.Forms.Padding(13, 6, 0, 0);
            this.lblYMax.Size = new System.Drawing.Size(92, 65);
            this.lblYMax.TabIndex = 3;
            this.lblYMax.Text = "Y max:";
            this.lblYMax.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblYMax.Click += new System.EventHandler(this.lblYMax_Click);
            // 
            // numYMax
            // 
            this.numYMax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(65)))));
            this.numYMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numYMax.DecimalPlaces = 2;
            this.numYMax.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.numYMax.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.numYMax.Location = new System.Drawing.Point(281, 70);
            this.numYMax.Margin = new System.Windows.Forms.Padding(5);
            this.numYMax.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numYMax.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numYMax.Name = "numYMax";
            this.numYMax.Size = new System.Drawing.Size(240, 39);
            this.numYMax.TabIndex = 7;
            this.numYMax.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numYMax.ValueChanged += new System.EventHandler(this.NumAxis_ValueChanged);
            // 
            // calcGroup
            // 
            this.calcGroup.Controls.Add(this.calcInputPanel);
            this.calcGroup.Controls.Add(this.lblCalcResult);
            this.calcGroup.Dock = System.Windows.Forms.DockStyle.Top;
            this.calcGroup.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.calcGroup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            this.calcGroup.Location = new System.Drawing.Point(0, 0);
            this.calcGroup.Margin = new System.Windows.Forms.Padding(5);
            this.calcGroup.Name = "calcGroup";
            this.calcGroup.Padding = new System.Windows.Forms.Padding(26, 32, 26, 26);
            this.calcGroup.Size = new System.Drawing.Size(422, 208);
            this.calcGroup.TabIndex = 4;
            this.calcGroup.TabStop = false;
            this.calcGroup.Text = "🔢 Калькулятор";
            // 
            // calcInputPanel
            // 
            this.calcInputPanel.Controls.Add(this.txtCalcInput);
            this.calcInputPanel.Controls.Add(this.btnCalc);
            this.calcInputPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.calcInputPanel.Location = new System.Drawing.Point(26, 68);
            this.calcInputPanel.Margin = new System.Windows.Forms.Padding(5);
            this.calcInputPanel.Name = "calcInputPanel";
            this.calcInputPanel.Size = new System.Drawing.Size(370, 64);
            this.calcInputPanel.TabIndex = 0;
            // 
            // txtCalcInput
            // 
            this.txtCalcInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(65)))));
            this.txtCalcInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCalcInput.Font = new System.Drawing.Font("Consolas", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtCalcInput.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(240)))));
            this.txtCalcInput.Location = new System.Drawing.Point(0, 6);
            this.txtCalcInput.Margin = new System.Windows.Forms.Padding(5);
            this.txtCalcInput.Name = "txtCalcInput";
            this.txtCalcInput.Size = new System.Drawing.Size(479, 40);
            this.txtCalcInput.TabIndex = 12;
            this.txtCalcInput.Text = "2+2*Sin(pi/2)";
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(200)))), ((int)(((byte)(100)))));
            this.btnCalc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalc.FlatAppearance.BorderSize = 0;
            this.btnCalc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalc.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Bold);
            this.btnCalc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCalc.ForeColor = System.Drawing.Color.White;
            this.btnCalc.Location = new System.Drawing.Point(496, 6);
            this.btnCalc.Margin = new System.Windows.Forms.Padding(5);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(112, 45);
            this.btnCalc.TabIndex = 13;
            this.btnCalc.Text = "";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            this.btnCalc.Paint += new System.Windows.Forms.PaintEventHandler(this.BtnCalc_Paint);
            // 
            // lblCalcResult
            // 
            this.lblCalcResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblCalcResult.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCalcResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.lblCalcResult.Location = new System.Drawing.Point(26, 140);
            this.lblCalcResult.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCalcResult.Name = "lblCalcResult";
            this.lblCalcResult.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.lblCalcResult.Size = new System.Drawing.Size(370, 42);
            this.lblCalcResult.TabIndex = 14;
            this.lblCalcResult.Text = "Результат:";
            // 
            // chartPanel
            // 
            this.chartPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.chartPanel.Controls.Add(this.chartFunctions);
            this.chartPanel.Controls.Add(this.chartToolbar);
            this.chartPanel.Controls.Add(this.statusBar);
            this.chartPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartPanel.Location = new System.Drawing.Point(0, 0);
            this.chartPanel.Margin = new System.Windows.Forms.Padding(5);
            this.chartPanel.Name = "chartPanel";
            this.chartPanel.Padding = new System.Windows.Forms.Padding(19, 13, 19, 0);
            this.chartPanel.Size = new System.Drawing.Size(2236, 1459);
            this.chartPanel.TabIndex = 0;
            // 
            // chartFunctions
            // 
            chartArea1.AxisX.LabelStyle.Font = new System.Drawing.Font("Segoe UI", 8F);
            chartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(110)))));
            chartArea1.AxisX.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(210)))));
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(235)))));
            chartArea1.AxisX.Title = "X";
            chartArea1.AxisX.TitleFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            chartArea1.AxisX.TitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            chartArea1.AxisY.LabelStyle.Font = new System.Drawing.Font("Segoe UI", 8F);
            chartArea1.AxisY.LabelStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(110)))));
            chartArea1.AxisY.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(210)))));
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(235)))));
            chartArea1.AxisY.Title = "Y";
            chartArea1.AxisY.TitleFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            chartArea1.AxisY.TitleForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            chartArea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            chartArea1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(230)))));
            chartArea1.Name = "MainArea";
            chartArea1.ShadowColor = System.Drawing.Color.Transparent;
            this.chartFunctions.ChartAreas.Add(chartArea1);
            this.chartFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.BackColor = System.Drawing.Color.Transparent;
            legend1.Font = new System.Drawing.Font("Segoe UI", 9F);
            legend1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(90)))));
            legend1.IsTextAutoFit = false;
            legend1.Name = "Legend1";
            this.chartFunctions.Legends.Add(legend1);
            this.chartFunctions.Location = new System.Drawing.Point(19, 96);
            this.chartFunctions.Margin = new System.Windows.Forms.Padding(5);
            this.chartFunctions.Name = "chartFunctions";
            this.chartFunctions.Padding = new System.Windows.Forms.Padding(13);
            series1.ChartArea = "MainArea";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartFunctions.Series.Add(series1);
            this.chartFunctions.Size = new System.Drawing.Size(2198, 1321);
            this.chartFunctions.TabIndex = 1;
            // 
            // chartToolbar
            // 
            this.chartToolbar.Controls.Add(this.btnSaveImage);
            this.chartToolbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.chartToolbar.Location = new System.Drawing.Point(19, 13);
            this.chartToolbar.Margin = new System.Windows.Forms.Padding(5);
            this.chartToolbar.Name = "chartToolbar";
            this.chartToolbar.Padding = new System.Windows.Forms.Padding(0, 13, 0, 13);
            this.chartToolbar.Size = new System.Drawing.Size(2198, 83);
            this.chartToolbar.TabIndex = 2;
            // 
            // btnSaveImage
            // 
            this.btnSaveImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnSaveImage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveImage.FlatAppearance.BorderSize = 0;
            this.btnSaveImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveImage.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSaveImage.ForeColor = System.Drawing.Color.White;
            this.btnSaveImage.Location = new System.Drawing.Point(0, 13);
            this.btnSaveImage.Margin = new System.Windows.Forms.Padding(5);
            this.btnSaveImage.Name = "btnSaveImage";
            this.btnSaveImage.Size = new System.Drawing.Size(348, 58);
            this.btnSaveImage.TabIndex = 2;
            this.btnSaveImage.Text = "💾 сохранить как PNG";
            this.btnSaveImage.UseVisualStyleBackColor = false;
            this.btnSaveImage.Click += new System.EventHandler(this.BtnSaveImage_Click);
            // 
            // statusBar
            // 
            this.statusBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(250)))));
            this.statusBar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.statusBar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusBar.Location = new System.Drawing.Point(19, 1417);
            this.statusBar.Name = "statusBar";
            this.statusBar.Padding = new System.Windows.Forms.Padding(2, 0, 22, 0);
            this.statusBar.Size = new System.Drawing.Size(2198, 42);
            this.statusBar.TabIndex = 0;
            this.statusBar.Text = "statusStrip1";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(305, 32);
            this.toolStripStatusLabel.Text = "Ready • 0 functions plotted";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(192F, 192F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(2698, 1459);
            this.Controls.Add(this.mainSplitContainer);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MinimumSize = new System.Drawing.Size(1904, 1157);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Инженерный калькулятор • визуализатор функций";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.mainSplitContainer.Panel1.ResumeLayout(false);
            this.mainSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mainSplitContainer)).EndInit();
            this.mainSplitContainer.ResumeLayout(false);
            this.sidebarPanel.ResumeLayout(false);
            this.functionGroup.ResumeLayout(false);
            this.functionGroup.PerformLayout();
            this.listGroup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFunctions)).EndInit();
            this.buttonContainer.ResumeLayout(false);
            this.scaleGroup.ResumeLayout(false);
            this.scaleGrid.ResumeLayout(false);
            this.scaleGrid.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numXMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numYMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numYMax)).EndInit();
            this.calcGroup.ResumeLayout(false);
            this.calcInputPanel.ResumeLayout(false);
            this.calcInputPanel.PerformLayout();
            this.chartPanel.ResumeLayout(false);
            this.chartPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartFunctions)).EndInit();
            this.chartToolbar.ResumeLayout(false);
            this.statusBar.ResumeLayout(false);
            this.statusBar.PerformLayout();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.SplitContainer mainSplitContainer;
        private System.Windows.Forms.Panel sidebarPanel;
        private System.Windows.Forms.GroupBox functionGroup;
        private System.Windows.Forms.Label lblExpression;
        private System.Windows.Forms.TextBox txtExpression;
        private System.Windows.Forms.Button btnAddFunction;
        private System.Windows.Forms.GroupBox listGroup;
        private System.Windows.Forms.DataGridView dgvFunctions;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFunction;
        private System.Windows.Forms.DataGridViewTextBoxColumn colColor;
        private System.Windows.Forms.Panel buttonContainer;
        private System.Windows.Forms.Button btnRemoveFunction;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox scaleGroup;
        private System.Windows.Forms.TableLayoutPanel scaleGrid;
        private System.Windows.Forms.Label lblXMin;
        private System.Windows.Forms.NumericUpDown numXMin;
        private System.Windows.Forms.Label lblXMax;
        private System.Windows.Forms.NumericUpDown numXMax;
        private System.Windows.Forms.Label lblYMin;
        private System.Windows.Forms.NumericUpDown numYMin;
        private System.Windows.Forms.Label lblYMax;
        private System.Windows.Forms.NumericUpDown numYMax;
        private System.Windows.Forms.GroupBox calcGroup;
        private System.Windows.Forms.Panel calcInputPanel;
        private System.Windows.Forms.TextBox txtCalcInput;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblCalcResult;
        private System.Windows.Forms.Panel chartPanel;
        private System.Windows.Forms.Panel chartToolbar;
        private System.Windows.Forms.Button btnSaveImage;
        private System.Windows.Forms.StatusStrip statusBar;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartFunctions;
    }
}