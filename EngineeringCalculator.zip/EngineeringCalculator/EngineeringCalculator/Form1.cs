﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using NCalc;

namespace EngineeringCalculator
{
    public partial class Form1 : Form
    {
        private List<FunctionItem> functions = new List<FunctionItem>();

        public Form1()
        {
            InitializeComponent();
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            if (chartFunctions.ChartAreas.Count == 0)
            {
                ChartArea ca = new ChartArea("MainArea");
                chartFunctions.ChartAreas.Add(ca);
            }

            ChartArea area = chartFunctions.ChartAreas[0];
            area.AxisX.Title = "X";
            area.AxisY.Title = "Y";
            area.AxisX.TitleFont = new Font("Segoe UI", 10, FontStyle.Bold);
            area.AxisY.TitleFont = new Font("Segoe UI", 10, FontStyle.Bold);
            area.AxisX.LabelStyle.Font = new Font("Segoe UI", 8);
            area.AxisY.LabelStyle.Font = new Font("Segoe UI", 8);
            area.BackColor = Color.FromArgb(245, 245, 255);

            UpdateChartRange();
            chartFunctions.Series.Clear();

            dgvFunctions.Columns.Clear();
            dgvFunctions.Columns.Add("colFunction", "Функция f(x) =");
            dgvFunctions.Columns.Add("colColor", "Цвет");
            dgvFunctions.Columns[0].Width = 280;
            dgvFunctions.Columns[1].Width = 145;
            dgvFunctions.BackgroundColor = Color.White;
            dgvFunctions.BorderStyle = BorderStyle.FixedSingle;

            this.numXMin.ValueChanged += NumAxis_ValueChanged;
            this.numXMax.ValueChanged += NumAxis_ValueChanged;
            this.numYMin.ValueChanged += NumAxis_ValueChanged;
            this.numYMax.ValueChanged += NumAxis_ValueChanged;
        }

        private void UpdateChartRange()
        {
            if (chartFunctions.ChartAreas.Count > 0)
            {
                chartFunctions.ChartAreas[0].AxisX.Minimum = (double)numXMin.Value;
                chartFunctions.ChartAreas[0].AxisX.Maximum = (double)numXMax.Value;
                chartFunctions.ChartAreas[0].AxisY.Minimum = (double)numYMin.Value;
                chartFunctions.ChartAreas[0].AxisY.Maximum = (double)numYMax.Value;
            }
        }

        private string FixFunctionCase(string expression)
        {
            string result = expression;
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\bsin\b", "Sin", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\bcos\b", "Cos", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\btan\b", "Tan", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\blog\b", "Log", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\bexp\b", "Exp", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\bsqrt\b", "Sqrt", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = result.Replace("^", "^");
            return result;
        }

        private string AddConstants(string expression)
        {
            string result = expression;
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\bpi\b", "Pi", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            result = System.Text.RegularExpressions.Regex.Replace(result, @"\be\b", "E", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            return result;
        }

        public void DgvFunctions_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 1)
            {
                ColorDialog cd = new ColorDialog();
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    functions[e.RowIndex].Color = cd.Color;
                    UpdateFunctionsGrid();
                    DrawAllFunctions();
                }
            }
        }

        public void BtnAddFunction_Click(object sender, EventArgs e)
        {
            string expr = txtExpression.Text.Trim();
            if (string.IsNullOrEmpty(expr))
            {
                MessageBox.Show("Введите выражение, например: Sin(x) или x^2", "Подсказка",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string fixedExpr = FixFunctionCase(expr);
            fixedExpr = AddConstants(fixedExpr);

            try
            {
                NCalc.Expression test = new NCalc.Expression(fixedExpr);
                test.Parameters["x"] = 1.0;
                test.Evaluate();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка в выражении: {ex.Message}\n\n" +
                    $"Доступные функции: Sin, Cos, Tan, Log, Exp, Sqrt\n" +
                    $"Константы: pi, e\n" +
                    $"Примеры: Sin(x) + Cos(x), 2*pi, x^2", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Random rnd = new Random();
            Color color = Color.FromArgb(rnd.Next(100, 255), rnd.Next(100, 255), rnd.Next(100, 255));

            functions.Add(new FunctionItem { Expression = fixedExpr, OriginalExpression = expr, Color = color });
            UpdateFunctionsGrid();
            DrawAllFunctions();

            txtExpression.Clear();
            txtExpression.Focus();
        }

        public void BtnRemoveFunction_Click(object sender, EventArgs e)
        {
            if (dgvFunctions.SelectedRows.Count > 0)
            {
                int index = dgvFunctions.SelectedRows[0].Index;
                if (index < functions.Count)
                {
                    functions.RemoveAt(index);
                    UpdateFunctionsGrid();
                    DrawAllFunctions();
                }
            }
            else if (functions.Count > 0)
            {
                MessageBox.Show("Выберите функцию для удаления (кликните по строке)", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void UpdateFunctionsGrid()
        {
            dgvFunctions.Rows.Clear();
            foreach (var f in functions)
            {
                int rowIndex = dgvFunctions.Rows.Add(f.OriginalExpression, f.Color.Name);
                dgvFunctions.Rows[rowIndex].Cells[1].Style.BackColor = f.Color;
            }
        }

        private void DrawAllFunctions()
        {
            if (functions.Count == 0)
            {
                chartFunctions.Series.Clear();
                return;
            }

            chartFunctions.Series.Clear();
            UpdateChartRange();

            double xMin = (double)numXMin.Value;
            double xMax = (double)numXMax.Value;
            double yMin = (double)numYMin.Value;
            double yMax = (double)numYMax.Value;

            int steps = 800;
            double step = (xMax - xMin) / steps;

            foreach (var func in functions)
            {
                Series series = new Series(func.OriginalExpression);
                series.ChartType = SeriesChartType.Line;
                series.BorderWidth = 2;
                series.Color = func.Color;
                series.LegendText = func.OriginalExpression;
                series.ToolTip = func.OriginalExpression;

                for (int i = 0; i <= steps; i++)
                {
                    double x = xMin + i * step;
                    double y = EvaluateFunction(func.Expression, x);

                    if (!double.IsNaN(y) && !double.IsInfinity(y) && y >= yMin - 10 && y <= yMax + 10)
                    {
                        series.Points.AddXY(x, y);
                    }
                    else
                    {
                        series.Points.AddXY(x, double.NaN);
                    }
                }
                chartFunctions.Series.Add(series);
            }
        }

        private double EvaluateFunction(string expression, double x)
        {
            try
            {
                NCalc.Expression e = new NCalc.Expression(expression);
                e.Parameters["x"] = x;
                e.Parameters["pi"] = Math.PI;
                e.Parameters["Pi"] = Math.PI;
                e.Parameters["e"] = Math.E;
                e.Parameters["E"] = Math.E;
                object result = e.Evaluate();
                return Convert.ToDouble(result);
            }
            catch
            {
                return double.NaN;
            }
        }

        public void BtnClear_Click(object sender, EventArgs e)
        {
            if (functions.Count > 0)
            {
                DialogResult result = MessageBox.Show("Очистить все функции?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    functions.Clear();
                    UpdateFunctionsGrid();
                    chartFunctions.Series.Clear();
                }
            }
        }

        public void BtnSaveImage_Click(object sender, EventArgs e)
        {
            if (chartFunctions.Series.Count == 0)
            {
                MessageBox.Show("Нет графиков для сохранения. Сначала добавьте функцию.", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PNG Image|*.png|JPEG Image|*.jpg|BMP Image|*.bmp";
            sfd.Title = "Сохранить график";
            sfd.FileName = $"graph_{DateTime.Now:yyyyMMdd_HHmmss}.png";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                chartFunctions.SaveImage(sfd.FileName, ChartImageFormat.Png);
                MessageBox.Show($"График успешно сохранён!\n{sfd.FileName}", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void BtnCalc_Click(object sender, EventArgs e)
        {
            string input = txtCalcInput.Text.Trim();
            if (string.IsNullOrEmpty(input))
            {
                lblCalcResult.Text = "Результат: введите выражение";
                return;
            }

            try
            {
                string fixedInput = FixFunctionCase(input);
                fixedInput = AddConstants(fixedInput);
                NCalc.Expression expr = new NCalc.Expression(fixedInput);
                expr.Parameters["pi"] = Math.PI;
                expr.Parameters["Pi"] = Math.PI;
                expr.Parameters["e"] = Math.E;
                expr.Parameters["E"] = Math.E;
                object result = expr.Evaluate();
                lblCalcResult.Text = $"Результат: {result}";
            }
            catch (Exception ex)
            {
                lblCalcResult.Text = $"Ошибка: {ex.Message}";
            }
        }
        private void BtnCalc_Paint(object sender, PaintEventArgs e)
        {
            Button btn = (Button)sender;
            string text = "=";

            using (Font font = new Font("Consolas", 14, FontStyle.Bold))
            using (SolidBrush brush = new SolidBrush(btn.ForeColor))
            {
                SizeF textSize = e.Graphics.MeasureString(text, font);

                float x = (btn.Width - textSize.Width) / 2;
                float y = (btn.Height - textSize.Height) / 2;

                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
                e.Graphics.DrawString(text, font, brush, x, y);
            }
        }

        public void NumAxis_ValueChanged(object sender, EventArgs e)
        {
            if (numXMin.Value >= numXMax.Value)
            {
                numXMax.Value = numXMin.Value + 0.01m;
            }
            if (numYMin.Value >= numYMax.Value)
            {
                numYMax.Value = numYMin.Value + 0.01m;
            }

            numXMin.Update();
            numXMax.Update();
            numYMin.Update();
            numYMax.Update();

            UpdateChartRange();

            DrawAllFunctions();
        }

        private void chartFunctions_Click(object sender, EventArgs e)
        {

        }

        private void calcGroup_Enter(object sender, EventArgs e)
        {

        }

        private void appTitleLabel_Click(object sender, EventArgs e)
        {

        }

        private void listGroup_Enter(object sender, EventArgs e)
        {

        }

        private void lblXMax_Click(object sender, EventArgs e)
        {

        }

        private void scaleGrid_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblYMax_Click(object sender, EventArgs e)
        {

        }

        private void dgvFunctions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

    public class FunctionItem
    {
        public string Expression { get; set; }
        public string OriginalExpression { get; set; }
        public Color Color { get; set; }
    }
}